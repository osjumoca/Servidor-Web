
package model;

public class Inventario {
    int serial;
    String nombre;
    String tipo; //1. Electronico / 2. Inmueble
    int costo;

    public Inventario() {
    }

    public Inventario(int serial, String nombre, String tipo, int costo) {
        this.serial = serial;
        this.nombre = nombre;
        this.tipo = tipo;
        this.costo = costo;
    }

    public int getSerial() {
        return serial;
    }

    public void setSerial(int serial) {
        this.serial = serial;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }

    @Override
    public String toString() {
        return "Inventario{" + "serial=" + serial + ", nombre=" + nombre + ", tipo=" + tipo + ", costo=" + costo + '}';
    }
    
    
}
