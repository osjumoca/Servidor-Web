
package model;
public class Historial {
    int serialH;
    String tipoH;
    String descripcionH;
    int costoH;
    String estadoH;

    public Historial() {
    }
    
    public Historial(int serialH, String tipoH, String descripcionH, int costoH, String estadoH) {
        this.serialH = serialH;
        this.tipoH = tipoH;
        this.descripcionH = descripcionH;
        this.costoH = costoH;
        this.estadoH = estadoH;
    }

    public int getSerialH() {
        return serialH;
    }

    public void setSerialH(int serialH) {
        this.serialH = serialH;
    }

    public String getTipoH() {
        return tipoH;
    }

    public void setTipoH(String tipoH) {
        this.tipoH = tipoH;
    }

    public String getDescripcionH() {
        return descripcionH;
    }

    public void setDescripcionH(String descripcionH) {
        this.descripcionH = descripcionH;
    }

    public int getCostoH() {
        return costoH;
    }

    public void setCostoH(int costoH) {
        this.costoH = costoH;
    }

    public String getEstadoH() {
        return estadoH;
    }

    public void setEstadoH(String estadoH) {
        this.estadoH = estadoH;
    }

    @Override
    public String toString() {
        return "Historial{" + "serialH=" + serialH + ", tipoH=" + tipoH + ", descripcionH=" + descripcionH + ", costoH=" + costoH + ", estadoH=" + estadoH + '}';
    }

    
}
