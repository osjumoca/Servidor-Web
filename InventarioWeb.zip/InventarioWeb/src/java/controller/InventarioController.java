package controller;

import db.InventarioDAO;
import db.SesionDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Inventario;
import model.Historial;

public class InventarioController extends HttpServlet {

    private InventarioDAO invDAO = new InventarioDAO();
    private SesionDAO SesionDAO = new SesionDAO();

    Inventario Inventario;
    String txtID;
    String user;
    String target;
    ArrayList<Inventario> data;
    ArrayList<Historial> historiales;
    ArrayList<Historial> info;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String serialBusqueda = request.getParameter("serialBusqueda");
        String action = ((request.getParameter("action") != null) ? request.getParameter("action") : "list");

        switch (action) {
            case "login":
                user = request.getParameter("user");
                String password = request.getParameter("password");
                if (SesionDAO.getUser(user, password) == true) {                  
                    request.setAttribute("data", data = invDAO.getEstudiantes());
                    request.setAttribute("user", user);
                    String role = SesionDAO.getRole(user, password);
                    request.setAttribute("role", role);
                    request.setAttribute("name", SesionDAO.getName(user, password));
                    
                    if(role.equals("rector") || role.equals("administrador")){
                        request.getRequestDispatcher("inventario/index.jsp").forward(request, response);
                    } else {
                    String mensajeError = "Usuario no encontrado, por favor intente de nuevo";
                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('" + mensajeError + "');");
                    out.println("window.location.href='index.jsp';");
                    out.println("</script>");
                }
            }
                break;
            case "list":
//                user = request.getParameter("user");
//                ArrayList<Inventario> data = invDAO.getEstudiantes();
//                request.setAttribute("data", data);
//                request.setAttribute("user", user);
//                request.getRequestDispatcher("inventario/index.jsp").forward(request, response);
//                break;
                user = request.getParameter("user");
    
                // Si hay un número de serie proporcionado, realiza la búsqueda
                 if (serialBusqueda != null && !serialBusqueda.isEmpty()) {
                    ArrayList<Inventario> data = invDAO.getEstudiantesBySerial(Integer.parseInt(serialBusqueda));
                    request.setAttribute("data", data);
                } else {
                // Si no hay número de serie, obtén todos los objetos
                ArrayList<Inventario> data = invDAO.getEstudiantes();
                request.setAttribute("data", data);
                }
    
                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/index.jsp").forward(request, response);
                break;
            case "listH":
//                user = request.getParameter("user");
//                ArrayList<Historial> info = invDAO.getHistorial();
//                request.setAttribute("info", info);
//                request.setAttribute("user", user);
//                request.getRequestDispatcher("inventario/indexH.jsp").forward(request, response);
//                break;
                user = request.getParameter("user");

                // Si hay un número de serie proporcionado, realiza la búsqueda
                if (serialBusqueda != null && !serialBusqueda.isEmpty()) {
                    info = invDAO.getHistorialBySerial(Integer.parseInt(serialBusqueda));
                    request.setAttribute("info", info);
                } else {
                    // Si no hay número de serie, obtén todos los historiales
                    info = invDAO.getHistorial();
                    request.setAttribute("info", info);
                }

                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/indexH.jsp").forward(request, response);
                break;
            case "delete":
                user = request.getParameter("user");
                request.setAttribute("user", user);
                txtID = request.getParameter("id");
                int id = Integer.parseInt(txtID);
                invDAO.deleteEstudiante(id);

                data = invDAO.getEstudiantes();
                request.setAttribute("data", data);
                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/index.jsp").forward(request, response);
                break;
            case "deleteH":
                user = request.getParameter("user");
                request.setAttribute("user", user);
                txtID = request.getParameter("id");
                int idH = Integer.parseInt(txtID);
                invDAO.deleteHistorial(idH);

                info = invDAO.getHistorial();
                request.setAttribute("info", info);
                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/indexH.jsp").forward(request, response);
                break;
            case "add":
                user = request.getParameter("user");
                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/registro.jsp").forward(request, response);
                break;
            case "addH":
                user = request.getParameter("user");
                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/historial.jsp").forward(request, response);
                break;
            case "save":
                user = request.getParameter("user");
                request.setAttribute("user", user);
                int serial = Integer.parseInt(request.getParameter("serial"));
                String nombre = request.getParameter("nombre");
                String tipo = request.getParameter("tipo");
                int costo = Integer.parseInt(request.getParameter("costo"));


                Inventario inventario = new Inventario(serial, nombre, tipo, costo);

                invDAO.addEstudiante(inventario);

                data = invDAO.getEstudiantes();
                request.setAttribute("data", data);
                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/index.jsp").forward(request, response);
                break;
            case "saveH":
                user = request.getParameter("user");
                request.setAttribute("user", user);
                int serialH = Integer.parseInt(request.getParameter("serial"));
                String tipoH = request.getParameter("tipo");
                String descripcionH = request.getParameter("descripcion");
                int costoH = Integer.parseInt(request.getParameter("costo"));
                String estadoH = request.getParameter("estado");


                Historial historial = new Historial(serialH, tipoH, descripcionH, costoH, estadoH);
                
                invDAO.addHistorial(historial);
                
                info = invDAO.getHistorial();
                request.setAttribute("info", info);
                request.setAttribute("user", user);
                request.getRequestDispatcher("inventario/indexH.jsp").forward(request, response);

    }
}

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}