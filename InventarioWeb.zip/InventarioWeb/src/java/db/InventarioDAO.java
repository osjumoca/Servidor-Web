package db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Inventario;
import model.Historial;

public class InventarioDAO {
    
    private ConexionDB db;

    public InventarioDAO() {
        this.db = ConexionDB.getInstance();
    }
    
    
    public ArrayList<Inventario> getEstudiantes() {
        ArrayList<Inventario> datos = new ArrayList();
        String sql = "SELECT * FROM inventario_Web.inventario;";

        try {
            PreparedStatement ps = db.getConexion().prepareStatement(sql);
            ResultSet rs1 = ps.executeQuery();
            while (rs1.next()) {
                int serial = rs1.getInt("serial");
                String nombre = rs1.getString("nombre");
                String tipo = rs1.getString("tipo");
                int costo = rs1.getInt("costo");
                
                Inventario est = new Inventario(serial, nombre, tipo, costo);

                datos.add(est);
            }
        } catch (SQLException ex) {
            Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datos;
    }
    
    public ArrayList<Historial> getHistorial() {
        ArrayList<Historial> info = new ArrayList();
        String sql = "SELECT * FROM inventario_Web.estado;";

        try {
            PreparedStatement ps = db.getConexion().prepareStatement(sql);
            ResultSet rs1 = ps.executeQuery();
            while (rs1.next()) {
                int serial = rs1.getInt("serial");
                String tipo = rs1.getString("tipo");
                String descripcion = rs1.getString("descripcion");
                int costo = rs1.getInt("costo");
                String estado = rs1.getString("estado");
                
                Historial est = new Historial(serial, tipo, descripcion, costo, estado);

                info.add(est);
            }
        } catch (SQLException ex) {
            Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return info;
    }
    
    public boolean getExisteEstudianteDocumento(int documento) {
        boolean encontrado = false;
        
        String sql = "SELECT * FROM inventario_Web.inventario where serial = ?;";

        try {
            PreparedStatement ps = db.getConexion().prepareStatement(sql);
            ps.setInt(1, documento);
            ResultSet rs1 = ps.executeQuery();
            
            if(rs1.next()){
                encontrado = true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return encontrado;
    }
    
    public void addHistorial(Historial est){
        String sql = "insert into inventario_Web.estado values (?, ?, ?, ?, ?);";
        try {
            PreparedStatement ps = db.getConexion().prepareStatement(sql);
            ps.setInt(1, est.getSerialH());
            ps.setString(2, est.getTipoH());
            ps.setString(3, est.getDescripcionH());
            ps.setInt(4, est.getCostoH());
            ps.setString(5, est.getEstadoH());
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    public void addEstudiante(Inventario est){
            // Primero, verifica si la ID ya existe en la base de datos
        String sqlVerificacion = "SELECT serial FROM inventario_Web.inventario WHERE serial = ?";
        try {
        PreparedStatement psVerificacion = db.getConexion().prepareStatement(sqlVerificacion);
        psVerificacion.setInt(1, est.getSerial());
        ResultSet rs = psVerificacion.executeQuery();
        
        if (rs.next()) {
            // La ID ya existe, puedes manejar el caso según tus requerimientos
            // Por ejemplo, mostrar un mensaje de error al usuario
            System.out.println("El serial ya existe en la base de datos.");
            return; // Termina la función para evitar la inserción
        }
            } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        String sql = "insert into inventario_Web.inventario values (?, ?, ?, ?);";
        try {
            PreparedStatement ps = db.getConexion().prepareStatement(sql);
            ps.setInt(1, est.getSerial());
            ps.setString(2, est.getNombre());
            ps.setString(3, est.getTipo());
            ps.setInt(4, est.getCosto());
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void deleteEstudiante(int id) {
        String sql = "DELETE FROM inventario_Web.inventario WHERE serial = ?;";
        try {
            PreparedStatement ps = db.getConexion().prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void deleteHistorial(int idH) {
        String sql = "DELETE FROM inventario_Web.estado WHERE serial = ?;";
        try {
            PreparedStatement ps = db.getConexion().prepareStatement(sql);
            ps.setInt(1, idH);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList<Historial> getHistorialBySerial(int serial) {
    ArrayList<Historial> info = new ArrayList();
    String sql = "SELECT * FROM inventario_Web.estado WHERE serial = ?;";

    try {
        PreparedStatement ps = db.getConexion().prepareStatement(sql);
        ps.setInt(1, serial);
        ResultSet rs1 = ps.executeQuery();
        while (rs1.next()) {
            int serialResult = rs1.getInt("serial");
            String tipo = rs1.getString("tipo");
            String descripcion = rs1.getString("descripcion");
            int costo = rs1.getInt("costo");
            String estado = rs1.getString("estado");

            Historial est = new Historial(serialResult, tipo, descripcion, costo, estado);

            info.add(est);
        }
    } catch (SQLException ex) {
        Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
    }
    return info;
}
    
    public ArrayList<Inventario> getEstudiantesBySerial(int serial) {
    ArrayList<Inventario> data = new ArrayList();
    String sql = "SELECT * FROM inventario_Web.inventario WHERE serial = ?;";

    try {
        PreparedStatement ps = db.getConexion().prepareStatement(sql);
        ps.setInt(1, serial);
        ResultSet rs1 = ps.executeQuery();
        while (rs1.next()) {
            int serialResult = rs1.getInt("serial");
            String nombre = rs1.getString("nombre");
            String tipo = rs1.getString("tipo");
            int costo = rs1.getInt("costo");

            Inventario est = new Inventario(serialResult, nombre, tipo, costo);

            data.add(est);
        }
    } catch (SQLException ex) {
        Logger.getLogger(InventarioDAO.class.getName()).log(Level.SEVERE, null, ex);
    }
    return data;
}
    
}
